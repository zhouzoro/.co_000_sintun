<div class="article-preview style1">
    <?php if(isset($previewItem)): ?>
        <!--TITLE-->
        <h2 class="article-title" href=<?php echo e('/'.$previewItem['type'].'/'.$previewItem['id']); ?>><?php echo e($previewItem['title']); ?></h2>

        <!--author info part including ship-->
        <div class="article-author">
            <a class='user-link'>
                <img src=<?php echo e('/images/user/'.$previewItem['author'].'.jpg'); ?> class="user-pic small circle">
                <span clspanss='username' href=<?php echo e('/user/'.$previewItem['authorID']); ?>><?php echo e($previewItem['authorName']); ?></a>
            </a>
            <label> from: </label>
            <a class="shipName" href=<?php echo e('/user/'.$previewItem['shipID']); ?>><?php echo e($previewItem['shipName']); ?></a>
        </div>

        <!--tags-->
        <div class="article-tags">
            <?php if(isset($previewItem['tags'])): ?>
                <?php foreach($previewItem['tags'] as $articleTag): ?>
                    <a class="tag" href=<?php echo e('/tags?tag='.$articleTag.'&from_category='.$previewItem['type']); ?>>tag1</a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!--cover pic-->
        <div class="article-cover">
            <img src=<?php echo e($previewItem['cover']); ?> href=<?php echo e('/'.$previewItem['type'].'/'.$previewItem['id']); ?>>
        </div>
        <div class="article-description">
            <p><?php echo e($previewItem['quote']); ?></p>
        </div>
        
        <!--some info like view count, comments, likes, etc -->
        <div class="article-meta">
            <div class="article-status">
                <a class="read">
                    <i class="fa fa-eye"></i>
                    <span class="count">146</span>
                </a>
                <a class="like">
                    <i class="fa fa-heart-o"></i>
                    <span class="count">171</span>
                </a>
                <a class="comment">
                    <i class="fa fa-comment-o"></i>
                    <span class="count">212</span>
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="article-title">
            <h2>Nothing like this</h2></div>
        <div class="article-author">
            <a class='user-link'>
                <img src="/images/user/007.jpg" class="user-pic small circle"></img><span>user 001</span>
            </a>
            <label> from: </label><a class="article-cruiser">ship 001</a></div>
        <div class="article-tags"><a class="tag">tag1</a><a class="tag">tag2</a><a class="tag">tag3</a></div>
        <div class="article-cover"><img src="https://placem.at/places?w=900&amp;random=0.7891012062318623"></div>
        <div class="article-description">
            <p>.article-description.article-description.article-description.article-description.article-description.article-description.article-description.article-description.article-description</p>
        </div>
        <div class="article-meta">
            <div class="article-status"><a class="read"><i class="fa fa-eye"></i><span class="count">146</span></a><a class="like"><i class="fa fa-heart-o"></i><span class="count">171</span></a><a class="comment"><i class="fa fa-comment-o"></i><span class="count">212</span></a></div>
        </div>
    <?php endif; ?>
</div>