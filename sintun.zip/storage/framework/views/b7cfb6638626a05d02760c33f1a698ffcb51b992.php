<!DOCTYPE html>
<html>
    <head>
        <?php $__env->startSection('page-title'); ?>
            <title>漫行邮轮</title>
        <?php echo $__env->yieldSection(); ?>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--meta(name='renderer' content='webkit')-->
        <meta http-equiv="X-UA-Compatible" content="IE=10" >
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta property="qc:admins" content="1455576553251356375" />
        <link rel="stylesheet" href="/stylesheets/dist/bootstrap-grid.min.css">
        <link rel="stylesheet" href="/stylesheets/dist/font-awesome.min.css">
        <!--link rel="stylesheet" href="/semantic/semantic.min.css"-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.css">

        <?php $__env->startSection('additional-styles'); ?>
            <link rel="stylesheet" href="/stylesheets/dist/style.min.css">
        <?php echo $__env->yieldSection(); ?>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
    </head>
    <body>
    <div class="hidden">
        <form class="user_auth_form" action="/user_auth" method="post" accept-charset="utf-8">
            <?php echo e(csrf_field()); ?>

        </form>
    </div>
        <div id="menu-hidden" class='ui left inline vertical sidebar menu hidden'>
            <?php echo $__env->make('layouts.mainMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class='pusher'>
            <!--common header-->
            <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!--body to show-->
            <?php $__env->startSection('main'); ?>
            <?php echo $__env->yieldSection(); ?>

        </div>
        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

        <?php $__env->startSection('common-scripts'); ?>
            <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.0/js.cookie.min.js"></script>
            custmised bootstrap -->
            <script src="/javascripts/dist/jquery-2.1.4.min.js"></script>
            <script src="/javascripts/dist/js.cookie.js"></script>
            <script src="/javascripts/dist/bootstrap.min.js"></script>
            <script src="/semantic/semantic.min.js"></script>
             <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.js"></script>-->
        <?php echo $__env->yieldSection(); ?>

        <?php $__env->startSection('additional-scripts'); ?>
            <!--script src='/javascripts/dist/vibrant.min.js' -->
            <script src="/javascripts/dist/main.babeled.min.js"></script>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>