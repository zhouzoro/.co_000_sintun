<header>
    <div id="nav">
        <a id='sidebar-toggle' onclick='toggleSidebar()'>
            <i class='fa fa-bars'></i>
        </a>
        <div class="logo-container no-boundry">
            <a class="logo" href='/'>
                <img src="/images/logo/normal.jpg">
            </a>
        </div>
        <?php echo $__env->make('layouts.mainMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="header-right">
            <div class="login-ops">

                <div class="out-links">
                    <div class="out-link qq">
                        <i class="fa fa-qq"></i>
                    </div>
                    <div class="out-link weixin">
                        <i class="fa fa-weixin"></i>
                    </div>
                    <div class="out-link weibo">
                        <i class="fa fa-weibo"></i>
                    </div>
                </div>

                <a class="login" href='/login'>登录</a>

            </div>

            <div class="user-ops hidden">
                <div class="user-button ui button data-position='bottom center'">
                    <img class='user-pic' src="/images/user/007.jpg" />
                </div>
                <div class="user-ops-popup ui popup bottom right transition hidden">
                    <div class="popup-content">
                        <label class='username'>User007</label>
                        <div class="divider border-top"><a class="user-profile-link" href="#">个人信息</a></div>
                        <div class="divider border-top"><a href="">设置</a><a href="#" class='logout' onclick='logOut()'>退出</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>