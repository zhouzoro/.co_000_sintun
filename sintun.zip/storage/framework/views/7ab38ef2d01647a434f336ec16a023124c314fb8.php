<?php $__env->startSection('page-title'); ?>
<title>联系我们——上海信豚实业有限公司</title><?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
@parent
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>