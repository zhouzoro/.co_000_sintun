<div id="carousel-slide" data-ride="carousel" data-pause="false" class="carousel slide carousel-fade">
	<?php echo $__env->make('contents.carouselThumbnail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div role="listbox" class="carousel-inner">
	    <?php if(isset($carouselItems)): ?>
	    	<?php foreach($carouselItems as $index=>$item): ?>
		        <div class='<?php echo e($index == 0?"item active":"item"); ?>'><img src='<?php echo e($item->cover); ?>' alt="slider image" class="slr-img cursor-pointer" href='<?php echo e("/cruiser_reports/".$item->id); ?>'>
		            <div class="carousel-caption">
		                <h2><a href='<?php echo e("/cruiser_reports/".$item->id); ?>'><?php echo e($item->title); ?></a></h2>
		                <label class="slabelextra">
		                    <a class="slabelsource" href="<?php echo e('/user/'.$item->author); ?>"><?php echo e($item->author_name); ?></a>
		                    <label class="slabeldate"><?php echo e(substr($item->updated_at,0,10)); ?></label>
		                </label>
		            </div>
		        </div>
	        <?php endforeach; ?>
	    <?php else: ?>
	        <div class="item active"><img src="https://placem.at/places?w=1400&amp;random=1" alt="slider image" class="slr-img cursor-pointer">
	            <div class="carousel-caption">
	                <h2 href="">全国首家邮轮分享与点评平台</h2>
	                <label class="slabelextra">
	                    <label class="slabeldate">2016</label>
	                    <label class="slabelsource">漫行邮轮</label>
	                </label>
	            </div>
	        </div>
	        <div class="item"><img src="https://placem.at/places?w=1400&amp;random=2" alt="slider image" class="slr-img cursor-pointer">
	            <div class="carousel-caption">
	                <h2 href="">全国首家邮轮分享与点评平台</h2>
	                <label class="slabelextra">
	                    <label class="slabeldate">2016</label>
	                    <label class="slabelsource">漫行邮轮</label>
	                </label>
	            </div>
	        </div>
	        <div class="item"><img src="https://placem.at/places?w=1400&amp;random=3" alt="slider image" class="slr-img cursor-pointer">
	            <div class="carousel-caption">
	                <h2 href="">全国首家邮轮分享与点评平台</h2>
	                <label class="slabelextra">
	                    <label class="slabeldate">2016</label>
	                    <label class="slabelsource">漫行邮轮</label>
	                </label>
	            </div>
	        </div>
	        <div class="item"><img src="https://placem.at/places?w=1400&amp;random=4" alt="slider image" class="slr-img cursor-pointer">
	            <div class="carousel-caption">
	                <h2 href="">全国首家邮轮分享与点评平台</h2>
	                <label class="slabelextra">
	                    <label class="slabeldate">2016</label>
	                    <label class="slabelsource">漫行邮轮</label>
	                </label>
	            </div>
	        </div>
	    <?php endif; ?>
    </div>
</div>
