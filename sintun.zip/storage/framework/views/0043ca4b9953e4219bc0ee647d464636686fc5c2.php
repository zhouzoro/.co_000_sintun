<?php $__env->startSection('additional-styles'); ?>
    @parent
    <link rel="stylesheet" href="/stylesheets/dist/upload.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-scripts'); ?>
    <script src='/javascripts/dist/vibrant.min.js' ></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/vue/1.0.20/vue.min.js' ></script>
    <script src='/tinymce/tinymce.min.js' ></script>
    @parent
    <script  src='/javascripts/dist/post.babeled.min.js' ></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    @parent
    <?php echo $__env->make('components.geoname', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>