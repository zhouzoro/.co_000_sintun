<?php $__env->startSection('main'); ?>

    <div class='container-fluid no-boundry'>
		<div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3">

			<?php echo $__env->make('inputs.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('common-scripts'); ?>
	<script src="/javascripts/dist/vue.min.js"></script>
	@parent
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>