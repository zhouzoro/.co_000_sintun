<footer class="container-fluid">
    <div class="footer-sub-container col-xs-12 col-sm-4 col-md-4">
        <div class="footer-sub slogan">
            <h2>全国首家邮轮分享与点评平台</h2>
        </div>
    </div>
    <div class="footer-sub-container col-xs-6 col-sm-3 col-md-3">
        <div class="footer-sub about">
            <a class="about-us">关于我们</a>
            <a class="about-mxcruise">关于漫行</a>
        </div>
    </div>
    <div class="footer-sub-container col-xs-6 col-sm-3 col-md-3">
        <div class="footer-sub site-map">
            <a class="site-link">邮轮服务</a>
            <a class="site-link">游记</a>
            <a class="site-link">攻略</a>
        </div>
    </div>
    <div class="footer-sub-container col-xs-12 col-sm-2 col-md-2">
        <div class="footer-sub social-links">
            <h3>关注我们</h3>
            <a class="social-link">
                <i class="fa fa-weixin"></i>
            </a>
            <a class="social-link">
                <i class="fa fa-weibo"></i>
            </a>
        </div>
    </div>
    <div class='bottom-indicator'></div>
</footer>