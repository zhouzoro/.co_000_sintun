<div id="articles-container">
    <?php echo $__env->make('components.articleMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="articles-list">
	    <?php if(isset($articles)): ?>
		    <?php foreach($articles as $article): ?>
			    <?php echo $__env->make('contents.postsMediumStyle',['previewItem'=>$article], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php endforeach; ?>
	    <?php else: ?>
		    <?php for($i=0;$i<6;$i++): ?>
			    <?php echo $__env->make('contents.postsMediumStyle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <?php endfor; ?>
	    <?php endif; ?>
    </div>
    <?php echo $__env->make('components.articleMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>