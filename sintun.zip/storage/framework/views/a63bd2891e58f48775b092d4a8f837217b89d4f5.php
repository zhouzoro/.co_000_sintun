
<div class="container-fluid no-boundry">
  <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
    <div id="user">
      <div id="user-profile"><div class="user-pic"><img src="<?php echo e('/images/user/'.$user->id.'.jpg'); ?>"/>
          <div class="change-pic">
            <label>替换</label>
          </div>
          </div>
          <div class="username"><?php echo e($user->username); ?></div></div>
      <div id="user-portfolio">
	      <h3>相关文章</h3>
	      <?php foreach($posts as $index => $post): ?>
		        <div class="post-prev">
				  <div class="title"><a href="<?php echo e('/cruiser_reports/'.$post->id); ?>"><?php echo e($post->title); ?></a></div>
				  <div class="prev"><?php echo e($post->quote); ?></div>
				</div>
	        <?php endforeach; ?>
        </div>
    </div>
  </div>
</div>