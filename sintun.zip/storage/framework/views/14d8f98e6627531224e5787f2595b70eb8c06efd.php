<div class="menu">
    <?php foreach($menuItems as $item): ?>
        <div class="menu-item">
            <a class="item" href=<?php echo e("/".$item["id"]); ?>><?php echo e($item["name"]); ?></a>
            <?php if(array_key_exists('sub', $item)): ?>
                <div class="sub-menu">
                    <?php foreach($item["sub"] as $subItem): ?>
                        <a class="item-sub" href=<?php echo e("/".$item["id"]."/".$subItem["id"]); ?>><?php echo e($subItem["name"]); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>