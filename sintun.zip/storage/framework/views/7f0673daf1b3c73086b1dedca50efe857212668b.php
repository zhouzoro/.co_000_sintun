<?php $__env->startSection('main'); ?>
	@parent
	<!--carousel-->
	<div id='carousel-home'>
		<?php echo $__env->make('contents.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('inputs.searchHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<!--main contents====================================-->
	<div id='body-content' class="container-fluid no-boundry">
		<div class="container-fluid no-boundry">
		    <div class="no-boundry col-xs-12 col-sm-12 col-md-10 col-md-offset-1 col-lg-8 col-lg-offset-2">
				<?php echo $__env->make('contents.homeInfoCenter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('contents.exprienceReportShowcase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<!--left side=================-->
		        <div class="content-side-left col-xs-12 col-sm-4 col-md-4 col-lg-4">
		            <?php echo $__env->make('contents.homeSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        </div>
				<!--=================left side-->

				<!--article list=================-->
		        <div id="content-main" class="no-boundry col-xs-12 col-sm-8 col-md-8 col-lg-8">
		            <?php echo $__env->make('layouts.articleList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        </div>
				<!--=================article list-->
		        <div class="content-side-right col-xs-12 col-sm-4 col-md-4 col-lg-4">
		            <?php echo $__env->make('contents.homeSide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        </div>
		    </div>
		</div>
	</div>
	<!--========================================main contents-->
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>