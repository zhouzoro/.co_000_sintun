<header>
    <div class="header-part logo-container no-boundry">
        <a class="logo" href='/'>
            <img src="sintun.png">
        </a>
        <a class="switch-lang">
            <i class="united states flag"></i>
            English
        </a>
    </div>
    <div class="header-part header-main">
        <h1 class="title">上海信豚实业有限公司</h1>
        <?php echo $__env->make('components.mainMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</header>