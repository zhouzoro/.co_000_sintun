<?php $__env->startSection('page-title'); ?>
	<title><?php echo e($post->title.' -- '.'漫行邮轮'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-styles'); ?>
    @parent
    <link rel="stylesheet" href="/stylesheets/dist/travelogue.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	@parent
	<?php echo $__env->make('contents.cruiser_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>