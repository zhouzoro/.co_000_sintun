<ol class="carousel-indicators" id="carousel-thumb">
	<?php if(isset($carouselItems)): ?>
    	<?php foreach($carouselItems as $index=>$item): ?>
	        <li data-target="#carousel-slide" data-slide-to=<?php echo e($index); ?> class=<?php echo e($index===0?"thumb active":"thumb"); ?> style='background-image: url(<?php echo e($item->cover); ?>)'></li>
        <?php endforeach; ?>
    <?php else: ?>
	    <li data-target="#carousel-slide" data-slide-to='0' class="active thumb" style='background-image: url("https://placem.at/places?w=1400&amp;random=1")'></li>
	    <li data-target="#carousel-slide" data-slide-to='1' class="thumb" style='background-image: url("https://placem.at/places?w=1400&amp;random=2")'></li>
	    <li data-target="#carousel-slide" data-slide-to='2' class="thumb" style='background-image: url("https://placem.at/places?w=1400&amp;random=3")'></li>
	    <li data-target="#carousel-slide" data-slide-to='3' class="thumb" style='background-image: url("https://placem.at/places?w=1400&amp;random=4")'></li>
    <?php endif; ?>
</ol>