<?php
$menuItems=[
	[
		"id" => "home",
	    "name" => "首页",
    ],
	[
	    "id" => "travelogue",
	    "name" => "游记",
	    "sub" => [
		    [
		        "id" => "cruise-logue",
		        "name" => "邮轮游记",
		    ], [
		        "id" => "non-cruise-logue",
		        "name" => "非邮轮游记",
		    ], 
	    ],
    ],
	[
	    "id" => "cheat-sheet",
	    "name" => "攻略",
    ],
	[
	    "id" => "dest",
	    "name" => "目的地",
    ],
	[
	    "id" => "cruiser",
	    "name" => "体验员",
    ],
	[
	    "id" => "community",
	    "name" => "社区",
    ],
];
?>