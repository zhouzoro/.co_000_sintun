
<div class="post-prev">
  <div class="title"><a href="{{'/cruiser_reports/'.$post->id}}">{{$post->title}}</a></div>
  <div class="prev">{{$post->quote}}</div>
</div>