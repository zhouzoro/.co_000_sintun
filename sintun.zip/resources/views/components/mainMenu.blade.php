
<div class="nav-bar-co"><a href="/about" class="menu-item">关于信豚</a><a href="/news" class="menu-item">信豚动态</a><a href="/products" class="menu-item">产品展示</a><a href="/cooperation" class="menu-item">商业合作</a><a href="/career" class="menu-item">招贤纳士</a><a href="/contact" class="menu-item">联系我们</a>
</div>