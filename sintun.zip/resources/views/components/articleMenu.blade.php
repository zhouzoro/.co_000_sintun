<div class="articles-menu">
	<a class="item">热门游记</a>
	<a class="item">最新发表</a>
	<a class="item">更多</a>
    <div class="new-article">
        <a class="ui button blue basic" href='/cruiser_reports/create'>
	        <i class="edit icon"></i>
	        <span>写游记</span>
        </a>
    </div>
</div>