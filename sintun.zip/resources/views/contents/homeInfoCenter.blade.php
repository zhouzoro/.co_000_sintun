<div id="home-info-center" class="info-center">
    <div class="title">
        <h2>邮轮小秘书</h2></div>
    <div class="service-menu"><a data-index='1' class="item">新手入门</a><a data-index='2' class="item">邮轮体验</a><a data-index='3' class="item">出行准备</a><a data-index='4' class="item">港口介绍</a><a data-index='5' class="item">常见问题</a></div>
    <div class="info-content-container">
        <div class="info-content-list">
            <div class="info-content get-started">
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.27633060584776103" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.20826850039884448" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.13385133887641132" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
            </div>
            <div class="info-content cruise-exprience">
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.37456171144731343" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.30846209917217493" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.5723187203984708" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
            </div>
            <div class="info-content travel-prep">
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.6741706591565162" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.2680497395340353" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.8725452735088766" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
            </div>
            <div class="info-content harbour-intro">
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.030063274316489697" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.21851547178812325" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.6689161087851971" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
            </div>
            <div class="info-content common-qs">
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.5938657214865088" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.422334450064227" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
                <div class="item-container">
                    <a href="#" class="item">
                        <div class="img-container"><img src="https://placem.at/places?h=400&amp;amp;random=0.8231067112646997" /></div>
                        <div class="title-container">
                            <label class="title">content title content title</label>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
