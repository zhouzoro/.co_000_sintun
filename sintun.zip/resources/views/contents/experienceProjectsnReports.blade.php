<div class="no-boundry col-xs-12 col-sm-6 col-md-6 col-lg-6">
    <div id="poster" class="card-split side-poster news-style"><img src="https://placem.at/people?w=900&amp;random=0.9291681405156851" class="background image">
        <div class="content">
            <div class="header">中国大学生邮轮体验员</div>
            <!--.metaspan.date= nw.date-->
            <!--.description= nw.quote-->
            <a href="" class="arrow">
                <div class="stick"></div>
                <div class="point"></div>
                <div class="wall"></div>
            </a>
        </div>
    </div>
</div>
<div class="no-boundry col-xs-12 col-sm-6 col-md-6 col-lg-6">
    <div id="review-report" class="card-split side-poster news-style"><img src="https://placem.at/places?h=400&amp;random=0.8929881765507162" class="background image">
        <div class="content">
            <div class="header">体验报告</div>
            <!--.metaspan.date= nw.date-->
            <!--.description= nw.quote-->
            <a href="" class="arrow">
                <div class="stick"></div>
                <div class="point"></div>
                <div class="wall"></div>
            </a>
        </div>
    </div>
</div>