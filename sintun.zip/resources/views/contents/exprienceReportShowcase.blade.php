<div id="report">
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <div class="report-compo report-poster">
            <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5">
                <div class="poster-img"><img src="https://placem.at/places?h=400&amp;random=0.5049997000023723"></div>
            </div>
            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                <div class="intro">
                    <h2>体验报告标题</h2>
                    <p>体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <div class="report-compo report-intro border-left">
            <h2>体验报告</h2>
            <a class="report-intro-list-nav up">
                <i class='fa fa-angle-up'></i>
            </a>
            <a class="report-intro-list-nav down">
                <i class='fa fa-angle-down'></i>
            </a>
            <div class="report-container-mini">
                <div class="report-intro-list">
                    <div class="item">
                        <div class='img-container'>
                            <img src="https://placem.at/places?h=100&amp;random=0.9320588656701148">
                        </div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.0747621889178"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.93201231148"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.074761234889178"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.0747611234549178"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.932058342701148"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                    <div class="item">
                    <div class='img-container'><img src="https://placem.at/places?h=100&amp;random=0.07476111454889178"></div>
                        <div class="title"><a href="">体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告体验报告</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>