<div id="strategy" class="card-split side-poster">
    <h3 class="side-sub-title">邮轮攻略</h3>
    <div class="article-cover"><img src="https://placem.at/places?w=400&amp;random=0.5922332443296909"></div>
</div>
<div id="community" class="card-split side-poster">
    <h3 class="side-sub-title">社区</h3>
    <div class="article-cover"><img src="https://placem.at/places?w=400&amp;random=0.04657397582195699"></div>
</div>
<div id="news" class="card-split side-poster">
    <h3 class="side-sub-title">邮轮资讯</h3>
    <ul>
        <li><a href="">邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯</a></li>
        <li><a href="">邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯</a></li>
        <li><a href="">邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯</a></li>
        <li><a href="">邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯邮轮资讯</a></li>
    </ul>
</div>
<div id="whales" class="card-split side-poster">
    <h3 class="side-sub-title">邮轮公司</h3>
    <div class="article-cover"><img src="https://placem.at/places?w=400&amp;random=0.8168768787290901"></div>
</div>
<div id="datas" class="card-split side-poster">
    <h3 class="side-sub-title">行业数据</h3>
    <ul>
        <li><a href="">行业数据行业数据行业数据行业数据行业数据行业数据</a></li>
        <li><a href="">行业数据行业数据行业数据行业数据行业数据行业数据</a></li>
        <li><a href="">行业数据行业数据行业数据行业数据行业数据行业数据</a></li>
        <li><a href="">行业数据行业数据行业数据行业数据行业数据行业数据</a></li>
    </ul>
</div>
<div id="secretary" class="card-split side-poster">
    <h3 class="side-sub-title">邮轮小秘书</h3>
    <div class="article-cover"><img src="https://placem.at/places?w=400&amp;random=0.0709780736360699"></div>
</div>