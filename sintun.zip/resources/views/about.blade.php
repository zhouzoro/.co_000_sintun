
@extends('layouts.app')
@section('main')
@parent
@endsection