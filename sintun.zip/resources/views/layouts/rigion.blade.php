
<div id="rigion">
  <h2 id="title">this is title </h2>
  <h3 id="subitle">this is subtitle</h3>
  <div class="place-list container-fluid">
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.2309")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.2309")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="item">
        <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
        <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
        <h3 class="name">name</h3>
      </div>
    </div>
  </div>
</div>