@extends('layouts.app')


@section('main')
	@parent
	@include('inputs.new_camp')
@endsection