
<div id="places">
  <div id="place-hero">
    <h2 id="quote">在别处</h2>
  </div>
  <div id="places-container">
    <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.09")" class="rigion">
      <h2 class="title">
        <label>霓虹国最热城市</label><a class="more">更多城市</a>
      </h2>
      <div class="place-list">
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.2309")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
      </div>
    </div>
    <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.12323509")" class="rigion">
      <h2 class="title">
        <label>泡菜国最热城市</label><a class="more">更多城市</a>
      </h2>
      <div class="place-list">
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.2309")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
      </div>
    </div>
    <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.1232109")" class="rigion">
      <h2 class="title">
        <label>腐国最热城市</label><a class="more">更多城市</a>
      </h2>
      <div class="place-list">
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=1.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.509")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
        <div class="item">
          <div style="background-image: url("https://placem.at/places?w=1400&amp;random=0.2309")" class="cover"></div>
          <div class="quote">.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote.quote</div>
          <h3 class="name">name</h3>
        </div>
      </div>
    </div>
  </div>
</div>