@extends('layouts.app')


@section('main')
	@parent
	@include('components.cruise_campus_prev')
@endsection