
@extends('layouts.app')
@section('page-title')
<title>产品展示——上海信豚实业有限公司</title>@endsection
@section('main')
<div class="products">
  <div class="product-frame row">
    <div class="col-md-6 col-sm-6 col-xs-6 product-container">
      <div class="product"><a class="exit-full-screen control"><i class="remove icon"></i></a>
        <div class="p-img"><img src="/images/products/1/0.jpg" class="active"/></div>
      </div>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6 p-intro">
      <h2 class="title">越南巴沙鱼产品</h2>
      <p class="intro">越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品</p>
    </div>
  </div>
  <div class="product-frame row">
    <div class="col-md-6 col-sm-6 col-xs-6 p-intro">
      <h2 class="title">越南巴沙鱼产品</h2>
      <p class="intro">越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品</p>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6 product-container">
      <div class="product"><a class="exit-full-screen control"><i class="remove icon"></i></a>
        <div class="p-img"><img src="/images/products/1/1.jpg" class="active"/></div>
      </div>
    </div>
  </div>
  <div class="product-frame row">
    <div class="col-md-6 col-sm-6 col-xs-6 product-container">
      <div class="product"><a class="exit-full-screen control"><i class="remove icon"></i></a>
        <div class="p-img"><img src="/images/products/1/2.jpg" class="active"/></div>
      </div>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-6 p-intro">
      <h2 class="title">越南巴沙鱼产品</h2>
      <p class="intro">越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品越南巴沙鱼产品</p>
    </div>
  </div>
</div>@endsection